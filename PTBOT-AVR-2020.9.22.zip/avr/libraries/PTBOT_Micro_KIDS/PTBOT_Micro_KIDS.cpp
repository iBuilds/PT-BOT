#include "PTBOT_Micro_KIDS.h"

/* LINE SENSOR ******************************************/
byte Num_Sensor = 4;
byte Sensor_PIN[] = {A1, A0, A7, A6};
unsigned int SENSOR_Back[] = {380, 283, 407, 360};    //Line
unsigned int SENSOR_White[] = {987, 987, 990, 986};   //Background
unsigned int SENSOR_READ[] = {500, 500, 100, 100};   //Read
/********************************************************/

Servo servo_gripper;
Servo servo_arm;

void MicroKIDS::IOSetup() {
  pinMode(Motor1_IN, OUTPUT);
  pinMode(Motor1_PWM, OUTPUT);
  pinMode(Motor2_IN, OUTPUT);
  pinMode(Motor2_PWM, OUTPUT);
  pinMode(Button_PIN, OUTPUT);

  Line_Mode = 0;
  Line_Address = 1;
  Background_Address = 101;
  for (byte i = 0; i < Num_Sensor; i ++) {
    byte Line_Address_Num = Line_Address + 5;
    unsigned int Value_Line = 0;
    unsigned int Value_Background = 0;
    for (Line_Address; Line_Address < Line_Address_Num; Line_Address ++) {
      Value_Line += EEPROM.read(Line_Address);
      Value_Background += EEPROM.read(Line_Address + 100);
    }
    Color_Line[i] = Value_Line;
    Color_Background[i] = Value_Background;
  }

  tone(Buzer_PIN, 975);   delay(100);
  tone(Buzer_PIN, 1138);  delay(100);
  tone(Buzer_PIN, 1486);  delay(100);
  noTone(Buzer_PIN);
  delay(1000);
}

void MicroKIDS::Tone(int note, unsigned int time) {
  tone(Buzer_PIN, note);
  delay(time);
  noTone(Buzer_PIN);
}

void MicroKIDS::servoWrite(byte pin, byte degree) {
  if (pin == 10 && _servo_gripper_attach == 0) {
    servo_gripper.attach(pin);
    _servo_gripper_attach = 1;
  }
  else if (pin == 9 && _servo_arm_attach == 0) {
    servo_arm.attach(pin);
    _servo_arm_attach = 1;
  }

  if (pin == 10) {
    servo_gripper.write(degree);
  }
  else if (pin == 9) {
    servo_arm.write(degree);
  }
}

void MicroKIDS::motorWrite(byte motor, int speed) {
  if (motor == 1) {
    if (speed > 0) {
      digitalWrite(Motor1_IN, HIGH);
      analogWrite(Motor1_PWM, speed);
    }
    else if (speed < 0) {
      speed = speed * (-1);
      digitalWrite(Motor1_IN, LOW);
      analogWrite(Motor1_PWM, speed);
    }
    else {
      digitalWrite(Motor1_IN, HIGH);
      analogWrite(Motor1_PWM, 0);
    }
  }
  else if (motor == 2) {
    if (speed > 0) {
      digitalWrite(Motor2_IN, HIGH);
      analogWrite(Motor2_PWM, speed);
    }
    else if (speed < 0) {
      speed = speed * (-1);
      digitalWrite(Motor2_IN, LOW);
      analogWrite(Motor2_PWM, speed);
    }
    else {
      digitalWrite(Motor2_IN, HIGH);
      analogWrite(Motor2_PWM, 0);
    }
  }
}

int MicroKIDS::LINECalibrate() {
  tone(Buzer_PIN, 1138);  delay(100);   noTone(Buzer_PIN);
  tone(Buzer_PIN, 1486);  delay(100);   noTone(Buzer_PIN);

  unsigned int Line_Cal[] = {0, 0, 0, 0, 0, 0, 0, 0};
  unsigned int Background_Cal[] = {0, 0, 0, 0, 0, 0, 0, 0};
  Line_Address = 1;
  Background_Address = 101;

  //Calibrate Line
  while (digitalRead(Button_PIN) == 0);
  tone(Buzer_PIN, 1486);   delay(20);   noTone(Buzer_PIN);
  for (byte i = 0; i < 20; i ++) {
    for (byte j = 0; j < Num_Sensor; j ++) {
      Line_Cal[j] += analogRead(Sensor_PIN[j]);
    }
    delay(50);
  }
  for (byte i = 0; i < Num_Sensor; i ++) {
    Line_Cal[i] = Line_Cal[i] / 20;
    Color_Line[i] = Line_Cal[i];

    byte Line_Address_Num = Line_Address + 5;
    for (Line_Address; Line_Address < Line_Address_Num; Line_Address ++) {
      if (Line_Cal[i] > 255) {
        EEPROM.update(Line_Address, 255);
        Line_Cal[i] = Line_Cal[i] - 255;
      }
      else {
        EEPROM.update(Line_Address, Line_Cal[i]);
        Line_Cal[i] = 0;
      }
    }
  }
  tone(Buzer_PIN, 1486);   delay(20);   noTone(Buzer_PIN);

  //Calibrate Background
  while (digitalRead(Button_PIN) == 0);
  tone(Buzer_PIN, 1486);   delay(20);   noTone(Buzer_PIN);
  for (byte i = 0; i < 20; i ++) {
    for (byte j = 0; j < Num_Sensor; j ++) {
      Background_Cal[j] += analogRead(Sensor_PIN[j]);
    }
    delay(50);
  }
  for (byte i = 0; i < Num_Sensor; i ++) {
    Background_Cal[i] = Background_Cal[i] / 20;
    Color_Background[i] = Background_Cal[i];

    byte Background_Address_Num = Background_Address + 5;
    for (Background_Address; Background_Address < Background_Address_Num; Background_Address ++) {
      if (Background_Cal[i] > 255) {
        EEPROM.update(Background_Address, 255);
        Background_Cal[i] = Background_Cal[i] - 255;
      }
      else {
        EEPROM.update(Background_Address, Background_Cal[i]);
        Background_Cal[i] = 0;
      }
    }
  }
  tone(Buzer_PIN, 1486);  delay(100);   noTone(Buzer_PIN);
  tone(Buzer_PIN, 1138);  delay(100);   noTone(Buzer_PIN);
}

void MicroKIDS::LINEToggle() {
  Line_Mode = !Line_Mode;
}

int MicroKIDS::GETPosition() {
  long Average = 0;
  long Sum_Value = 0;
  bool ON_Line = 0;

  for (byte i = 0; i < Num_Sensor; i ++) {
    int Value_Sensor;
    if (Line_Mode == 0) {
      Value_Sensor = map(analogRead(Sensor_PIN[i]), Color_Line[i], Color_Background[i], 1000, 0);
      if (Value_Sensor < 0) {
        Value_Sensor = 0;
      }
      else if (Value_Sensor > 1000) {
        Value_Sensor = 1000;
      }
    }
    else {
      Value_Sensor = map(analogRead(Sensor_PIN[i]), Color_Background[i], Color_Line[i], 1000, 0);
      if (Value_Sensor < 0) {
        Value_Sensor = 0;
      }
      else if (Value_Sensor > 1000) {
        Value_Sensor = 1000;
      }
    }
    if (Value_Sensor > 200) {
      ON_Line = 1;
      Average += (long)Value_Sensor * (i * 1000);
      Sum_Value += Value_Sensor;
    }
  }
  if (ON_Line == 0){
    if (Last_Position < (Num_Sensor - 1) * 1000 / 2){
      return (Num_Sensor - 1) * 1000;
    }
    else{
      return 0;
    }
  }
  Last_Position = Average / Sum_Value;
  return ((Num_Sensor - 1) * 1000) - Last_Position;
}

int MicroKIDS::GETDistance() {
  pinMode(TRIGGER_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  digitalWrite(TRIGGER_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIGGER_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIGGER_PIN, LOW);
  duration = pulseIn(ECHO_PIN, HIGH, 3000);
  if (duration == 0) {
	  duration = 3000; 
  }
  distance_cm = duration / 29 / 2 ;
	return distance_cm;
}