This library is based on
  - Servo
  - EEPROM
  - SPI
  - Wire