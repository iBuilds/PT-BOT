#ifndef PTBOT_Micro_KIDS_h
#define PTBOT_Micro_KIDS_h

#if defined(ARDUINO) || (ARDUINO >= 100)
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "Arduino.h"
#include <Servo.h>
#include <EEPROM.h>

/* DEFINE PIN *******************************************/
#define Buzer_PIN 5
#define Button_PIN 4

#define Motor1_IN 8
#define Motor1_PWM 6
#define Motor2_IN 7
#define Motor2_PWM 3
/********************************************************/

/* NOTE BUZZER ******************************************/
#define note_C 663
#define note_D 727
#define note_E 800
#define note_F 838
#define note_G 923
#define note_A 1020
#define note_B 1127
#define note_CC 1286
/********************************************************/

class MicroKIDS {
  public:
    //SETUP INPUT AND OUTPUT
    void IOSetup();

    //BUZZER
    void Tone(int note, unsigned int time);

    //CONTORL SERVO
    void servoWrite(byte pin, byte degree);

    //CONTROL MOTOR
    void motorWrite(byte motor, int speed);

    //CALIBRATE LINE SENSOR AND SAVE TO EEPROM
    int LINECalibrate();

    //CHANGE COLOR LINE
    void LINEToggle();

    //GET POSITION FROM LINE SENSOR
    int GETPosition();

  private:
    bool _servo_gripper_attach = 0;
    bool _servo_arm_attach = 0;

    /* LINE SENSOR ******************************************/
    byte Line_Address;
    byte Background_Address;
    unsigned int Color_Line[8];
    unsigned int Color_Background[8];
    unsigned int Last_Position;
    bool Line_Mode;
    byte _chartpin[8];
    byte _numchart;
    /********************************************************/
};

#endif