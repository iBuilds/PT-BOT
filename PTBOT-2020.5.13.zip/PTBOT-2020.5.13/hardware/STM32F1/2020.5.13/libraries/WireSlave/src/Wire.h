#pragma once
#include "Wire_slave.h"

//#error "Something is trying to include Wire.h when Wire_slave.h is already included, they are mutually exclusive"
