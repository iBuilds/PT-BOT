#include "PTBOT_Atom.h"
#include "logo.h"

/* LINE SENSOR ******************************************/
unsigned int SENSOR_Back[] = {1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000};    //Line
unsigned int SENSOR_White[] = {100, 100, 100, 100, 100, 100, 100, 100};   //Background
unsigned int SENSOR_READ[] = {500, 500, 100, 100, 100, 100, 100, 100};   //Read
/********************************************************/

Adafruit_MCP3008 adc;
Adafruit_ILI9341_STM dply = Adafruit_ILI9341_STM(TFT_CS, TFT_DC);
Adafruit_SSD1306 display(OLED_RESET);

ATOM::ATOM(byte model) {
  _model = model;
}

void ATOM::IOSetup() {
  pinMode(Buzer_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  pinMode(Button_PIN, INPUT);

  if (_model == ATOMX4) {
    pinMode(ATOM128_Motor1_IN, OUTPUT);
    pinMode(ATOM128_Motor1_PWM, OUTPUT);
    pinMode(ATOM128_Motor2_IN, OUTPUT);
    pinMode(ATOM128_Motor2_PWM, OUTPUT);
    pinMode(ATOM128_Motor3_IN, OUTPUT);
    pinMode(ATOM128_Motor3_PWM, OUTPUT);
    pinMode(ATOM128_Motor4_IN, OUTPUT);
    pinMode(ATOM128_Motor4_PWM, OUTPUT);

    digitalWrite(LED_PIN, HIGH);
    adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
    dply.begin();
    dply.setRotation(1);
    dply.fillScreen(WHITE);
    int16_t i, j, byteWidth = (259 + 7) / 8;
    uint8_t byte;
    for (j = 0; j < 106; j++) {
      for (i = 0; i < 259; i++) {
        if (i & 7) byte <<= 1;
        else byte = pgm_read_byte(logo + j * byteWidth + i / 8);
        if (byte & 0x80) dply.drawPixel(30 + i, 67 + j, BLACK);
      }
    }
  }
  else if (_model == ATOMX2) {
    pinMode(ATOM64_Motor1_IN1, OUTPUT);
    pinMode(ATOM64_Motor1_IN2, OUTPUT);
    pinMode(ATOM64_Motor1_PWM, OUTPUT);
    pinMode(ATOM64_Motor2_IN1, OUTPUT);
    pinMode(ATOM64_Motor2_IN2, OUTPUT);
    pinMode(ATOM64_Motor2_PWM, OUTPUT);

    digitalWrite(LED_PIN, HIGH);
    adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
    dply.begin();
    dply.setRotation(1);
    dply.fillScreen(WHITE);
    int16_t i, j, byteWidth = (259 + 7) / 8;
    uint8_t byte;
    for (j = 0; j < 106; j++) {
      for (i = 0; i < 259; i++) {
        if (i & 7) byte <<= 1;
        else byte = pgm_read_byte(logo + j * byteWidth + i / 8);
        if (byte & 0x80) dply.drawPixel(30 + i, 67 + j, BLACK);
      }
    }
  }
  else if (_model == ATOMmini) {
    pinMode(ATOM64_Motor1_IN1, OUTPUT);
    pinMode(ATOM64_Motor1_IN2, OUTPUT);
    pinMode(ATOM64_Motor1_PWM, OUTPUT);
    pinMode(ATOM64_Motor2_IN1, OUTPUT);
    pinMode(ATOM64_Motor2_IN2, OUTPUT);
    pinMode(ATOM64_Motor2_PWM, OUTPUT);

    digitalWrite(LED_PIN, HIGH);
    display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
    display.clearDisplay();
    display.display();
  }

  delay(2000);
  tone(Buzer_PIN, 535);   delay(100);
  tone(Buzer_PIN, 698);   delay(100);
  tone(Buzer_PIN, 1046);  delay(100);
  pinMode(Buzer_PIN, INPUT);
}

void ATOM::Tone(int note, unsigned int time) {
  pinMode(Buzer_PIN, OUTPUT);
  tone(Buzer_PIN, note);
  delay(time);
  pinMode(Buzer_PIN, INPUT);
}

unsigned int ATOM::ADCRead(byte channel) {
  adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
  return adc.readADC(channel);
}

void ATOM::LINESensorSET(byte adcchannel[], byte num_sensor) {
  Line_Mode = 0;
  for (byte i = 0; i < num_sensor; i ++) {
    Sensor_PIN[i] = adcchannel[i];
    _chartpin[i] = adcchannel[i];
  }
  Num_Sensor = num_sensor;
  _numchart = num_sensor;

  Line_Address = 1;
  Background_Address = 101;
  for (byte i = 0; i < Num_Sensor; i ++) {
    byte Line_Address_Num = Line_Address + 5;
    unsigned int Value_Line = 0;
    unsigned int Value_Background = 0;
    for (Line_Address; Line_Address < Line_Address_Num; Line_Address ++) {
      Value_Line += EEPROM.read(Line_Address);
      Value_Background += EEPROM.read(Line_Address + 100);
    }
    Color_Line[i] = Value_Line;
    Color_Background[i] = Value_Background;
  }
}

void ATOM::LINECalibrate() {
  tone(Buzer_PIN, 698);   delay(100);   noTone(Buzer_PIN);
  tone(Buzer_PIN, 1046);  delay(100);   noTone(Buzer_PIN);

  unsigned int Line_Cal[] = {0, 0, 0, 0, 0, 0, 0, 0};
  unsigned int Background_Cal[] = {0, 0, 0, 0, 0, 0, 0, 0};
  unsigned long Timer = millis();
  Line_Address = 1;
  Background_Address = 101;
  dply.begin();
  dply.setRotation(_rotation);
  dply.writeFillRect(0, 0, 320, 32, BLACK);

  //Calibrate Line
  while (digitalRead(Button_PIN) == 0) {
    if (millis() - Timer >= 500) {
      digitalWrite(LED_PIN, !digitalRead(LED_PIN));
      Timer = millis();
    }
    int point = 9;
    int value = 0;
    int value_last[8];
    for (int i = 0; i < Num_Sensor; i ++) {
      adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
      value = adc.readADC(Sensor_PIN[i]);
      dply.begin();
      dply.setRotation(_rotation);
      if (value <= 0) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print("0   ");
      }
      else if (value > 0 && value < 10) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("   ");
      }
      else if (value >= 10 && value < 100) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("  ");
      }
      else if (value >= 100 && value < 1000) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print(" ");
      }
      else {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
      }
      dply.begin();
      dply.setRotation(_rotation);
      dply.drawRect(point - 1, 39, 32, 240, BLACK);
      dply.fillTriangle(point + 9, 32, point + 19, 32, point + 14, 37, BLACK);
      if (value < value_last[i]) {
        int map_value = map(value, 0, 1023, 240, 40);
        int map_value_last = map(value_last[i], 0, 1023, 240, 40);
        dply.writeFillRect(point, 40, 30, map_value_last - 40, _fillcolor);
        dply.writeFillRect(point, map_value, 30, 240, WHITE);
      }
      else if (value <= 0) {
        dply.writeFillRect(point, 40, 30, 240, _fillcolor);
      }
      else {
        int map_value = map(value, 0, 1023, 240, 40);
        dply.writeFillRect(point, map_value, 30, 240, WHITE);
      }
      value_last[i] = value;
      point += 39;
    }
  }
  digitalWrite(LED_PIN, 1);
  tone(Buzer_PIN, 1046);   delay(20);   noTone(Buzer_PIN);
  dply.begin();
  dply.setRotation(_rotation);
  dply.fillScreen(_fillcolor);
  dply.setCursor(80, 112);
  dply.setTextColor(WHITE);
  dply.setTextSize(2);
  dply.println("Calculating...");
  for (byte i = 0; i < 20; i ++) {
    digitalWrite(LED_PIN, !digitalRead(LED_PIN));
    for (byte j = 0; j < Num_Sensor; j ++) {
      adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
      Line_Cal[j] += adc.readADC(Sensor_PIN[j]);
    }
    delay(50);
  }
  dply.begin();
  dply.setRotation(_rotation);
  dply.fillScreen(_fillcolor);
  dply.writeFillRect(0, 0, 320, 32, BLACK);
  for (byte i = 0; i < Num_Sensor; i ++) {
    Line_Cal[i] = Line_Cal[i] / 20;
    Color_Line[i] = Line_Cal[i];

    byte Line_Address_Num = Line_Address + 5;
    for (Line_Address; Line_Address < Line_Address_Num; Line_Address ++) {
      if (Line_Cal[i] > 255) {
        EEPROM.update(Line_Address, 255);
        Line_Cal[i] = Line_Cal[i] - 255;
      }
      else {
        EEPROM.update(Line_Address, Line_Cal[i]);
        Line_Cal[i] = 0;
      }
    }
  }
  tone(Buzer_PIN, 1046);   delay(20);   noTone(Buzer_PIN);

  //Calibrate Background
  Timer = millis();
  while (digitalRead(Button_PIN) == 0) {
    if (millis() - Timer >= 500) {
      digitalWrite(LED_PIN, !digitalRead(LED_PIN));
      Timer = millis();
    }
    int point = 9;
    int value = 0;
    int value_last[8];
    for (int i = 0; i < Num_Sensor; i ++) {
      adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
      value = adc.readADC(Sensor_PIN[i]);
      dply.begin();
      dply.setRotation(_rotation);
      if (value <= 0) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print("0   ");
      }
      else if (value > 0 && value < 10) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("   ");
      }
      else if (value >= 10 && value < 100) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("  ");
      }
      else if (value >= 100 && value < 1000) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print(" ");
      }
      else {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
      }
      dply.begin();
      dply.setRotation(_rotation);
      dply.drawRect(point - 1, 39, 32, 240, BLACK);
      dply.fillTriangle(point + 9, 32, point + 19, 32, point + 14, 37, BLACK);
      if (value < value_last[i]) {
        int map_value = map(value, 0, 1023, 240, 40);
        int map_value_last = map(value_last[i], 0, 1023, 240, 40);
        dply.writeFillRect(point, 40, 30, map_value_last - 40, _fillcolor);
        dply.writeFillRect(point, map_value, 30, 240, WHITE);
      }
      else if (value <= 0) {
        dply.writeFillRect(point, 40, 30, 240, _fillcolor);
      }
      else {
        int map_value = map(value, 0, 1023, 240, 40);
        dply.writeFillRect(point, map_value, 30, 240, WHITE);
      }
      value_last[i] = value;
      point += 39;
    }
  }
  digitalWrite(LED_PIN, 1);
  tone(Buzer_PIN, 1046);   delay(20);   noTone(Buzer_PIN);
  dply.begin();
  dply.setRotation(_rotation);
  dply.fillScreen(_fillcolor);
  dply.setCursor(80, 112);
  dply.setTextColor(WHITE);
  dply.setTextSize(2);
  dply.println("Calculating...");
  for (byte i = 0; i < 20; i ++) {
    digitalWrite(LED_PIN, !digitalRead(LED_PIN));
    for (byte j = 0; j < Num_Sensor; j ++) {
      adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
      Background_Cal[j] += adc.readADC(Sensor_PIN[j]);
    }
    delay(50);
  }
  dply.begin();
  dply.setRotation(_rotation);
  dply.fillScreen(_fillcolor);
  dply.writeFillRect(0, 0, 320, 32, BLACK);
  for (byte i = 0; i < Num_Sensor; i ++) {
    Background_Cal[i] = Background_Cal[i] / 20;
    Color_Background[i] = Background_Cal[i];

    byte Background_Address_Num = Background_Address + 5;
    for (Background_Address; Background_Address < Background_Address_Num; Background_Address ++) {
      if (Background_Cal[i] > 255) {
        EEPROM.update(Background_Address, 255);
        Background_Cal[i] = Background_Cal[i] - 255;
      }
      else {
        EEPROM.update(Background_Address, Background_Cal[i]);
        Background_Cal[i] = 0;
      }
    }
  }
  tone(Buzer_PIN, 1046);  delay(100);   noTone(Buzer_PIN);
  tone(Buzer_PIN, 698);   delay(100);   noTone(Buzer_PIN);
  dply.begin();
  dply.setRotation(_rotation);
  dply.fillScreen(_fillcolor);
}

void ATOM::LINEToggle() {
  Line_Mode = !Line_Mode;
}

int ATOM::GETPosition() {
  adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
  long Average = 0;
  long Sum_Value = 0;
  bool ON_Line = 0;

  for (byte i = 0; i < Num_Sensor; i ++) {
    int Value_Sensor;
    if (Line_Mode == 0) {
      Value_Sensor = map(adc.readADC(Sensor_PIN[i]), Color_Line[i], Color_Background[i], 1000, 0);
      if (Value_Sensor < 0) {
        Value_Sensor = 0;
      }
      else if (Value_Sensor > 1000) {
        Value_Sensor = 1000;
      }
    }
    else {
      Value_Sensor = map(adc.readADC(Sensor_PIN[i]), Color_Background[i], Color_Line[i], 1000, 0);
      if (Value_Sensor < 0) {
        Value_Sensor = 0;
      }
      else if (Value_Sensor > 1000) {
        Value_Sensor = 1000;
      }
    }
    if (Value_Sensor > 200) {
      ON_Line = 1;
      Average += (long)Value_Sensor * (i * 1000);
      Sum_Value += Value_Sensor;
    }
  }
  if (ON_Line == 0){
    if (Last_Position < (Num_Sensor - 1) * 1000 / 2){
      return (Num_Sensor - 1) * 1000;
    }
    else{
      return 0;
    }
  }
  Last_Position = Average / Sum_Value;
  return ((Num_Sensor - 1) * 1000) - Last_Position;
}

void ATOM::LINEChartSET(byte adcchannel[], byte num_sensor) {
  for (byte i = 0; i < num_sensor; i ++) {
    _chartpin[i] = adcchannel[i];
  }
  _numchart = num_sensor;
}

void ATOM::LINEChartSHOW(int16_t x) {
  int point = x;
  int value = 0;
  int value_last[8];
  dply.begin();
  dply.setRotation(_rotation);
  if (millis() - _timer > 100) {
    dply.writeFillRect(0, 0, 320, 32, BLACK);
  }
  for (int i = 0; i < _numchart; i ++) {
    if (Line_Mode == 0) {
      adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
      value = map(adc.readADC(_chartpin[i]), Color_Line[i], Color_Background[i], 1000, 0);
      dply.begin();
      dply.setRotation(_rotation);
      if (value < 0) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print("0   ");
      }
      else if (value > 0 && value < 10) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("   ");
      }
      else if (value >= 10 && value < 100) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("  ");
      }
      else if (value >= 100 && value < 1000) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print(" ");
      }
      else if (value > 1000) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print("1000");
      }
      else {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
      }
    }
    else {
      adc.begin(CLOCK_PIN, MOSI_PIN, MISO_PIN, SS_ADC_PIN);
      value = map(adc.readADC(_chartpin[i]), Color_Background[i], Color_Line[i], 1000, 0);
      dply.begin();
      dply.setRotation(_rotation);
      if (value < 0) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print("0   ");
      }
      else if (value > 0 && value < 10) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("   ");
      }
      else if (value >= 10 && value < 100) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print("  ");
      }
      else if (value >= 100 && value < 1000) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
        dply.print(" ");
      }
      else if (value > 1000) {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print("1000");
      }
      else {
        dply.setCursor(point + 3, 15);
        dply.setTextColor(WHITE, BLACK);
        dply.setTextSize(1);
        dply.print(value);
      }
    }
    dply.begin();
    dply.setRotation(_rotation);
    dply.drawRect(point - 1, 39, 32, 240, BLACK);
    dply.fillTriangle(point + 9, 32, point + 19, 32, point + 14, 37, BLACK);
    if (value < value_last[i]) {
      int map_value = map(value, 0, 1000, 240, 40);
      int map_value_last = map(value_last[i], 0, 1000, 240, 40);
      if (map_value < 40) {
        map_value = 40;
      }
      else if (map_value > 240) {
        map_value = 240;
      }
      dply.writeFillRect(point, 40, 30, map_value_last - 40, _fillcolor);
      dply.writeFillRect(point, map_value, 30, 240, WHITE);
    }
    else {
      int map_value = map(value, 0, 1000, 240, 40);
      if (map_value < 40) {
        map_value = 40;
      }
      else if (map_value > 240) {
        map_value = 240;
      }
      dply.writeFillRect(point, map_value, 30, 240, WHITE);
    }
    value_last[i] = value;
    point += 39;
  }
  _timer = millis();
}

void ATOM::servoWrite(byte pin, byte degree) {
  pinMode(pin, PWM);
  if (pin == PA9 || pin == PA10) {
    Timer1.setPrescaleFactor(22);
    Timer1.setOverflow(Pulse_Width_Servo);
  }
  if (pin == PB0 || pin == PB1) {
    Timer3.setPrescaleFactor(22);
    Timer3.setOverflow(Pulse_Width_Servo);
  }
  if (pin == PA1 || pin == PA2 || pin == PA3) {
    Timer2.setPrescaleFactor(22);
    Timer2.setOverflow(Pulse_Width_Servo);
  }
  pwmWrite(pin, map(degree, 0, 180, (Pulse_Width_Servo / 20 * 0.5), (Pulse_Width_Servo / 20 * 2.5)));
}

void ATOM::motorWrite(byte motor, int speed) {
  if (_model == ATOMX4) {
    if (motor == 1) {
      if (speed > 0) {
        digitalWrite(ATOM128_Motor1_IN, HIGH);
        analogWrite(ATOM128_Motor1_PWM, abs(speed));
      }
      else if (speed < 0) {
        digitalWrite(ATOM128_Motor1_IN, LOW);
        analogWrite(ATOM128_Motor1_PWM, abs(speed));
      }
      else {
        digitalWrite(ATOM128_Motor1_IN, LOW);
        analogWrite(ATOM128_Motor1_PWM, 0);
      }
    }
    else if (motor == 2) {
      if (speed > 0) {
        digitalWrite(ATOM128_Motor2_IN, HIGH);
        analogWrite(ATOM128_Motor2_PWM, abs(speed));
      }
      else if (speed < 0) {
        digitalWrite(ATOM128_Motor2_IN, LOW);
        analogWrite(ATOM128_Motor2_PWM, abs(speed));
      }
      else {
        digitalWrite(ATOM128_Motor2_IN, LOW);
        analogWrite(ATOM128_Motor2_PWM, 0);
      }
    }
    else if (motor == 3) {
      if (speed > 0) {
        digitalWrite(ATOM128_Motor3_IN, HIGH);
        analogWrite(ATOM128_Motor3_PWM, abs(speed));
      }
      else if (speed < 0) {
        digitalWrite(ATOM128_Motor3_IN, LOW);
        analogWrite(ATOM128_Motor3_PWM, abs(speed));
      }
      else {
        digitalWrite(ATOM128_Motor3_IN, LOW);
        analogWrite(ATOM128_Motor3_PWM, 0);
      }
    }
    else if (motor == 4) {
      if (speed > 0) {
        digitalWrite(ATOM128_Motor4_IN, HIGH);
        analogWrite(ATOM128_Motor4_PWM, abs(speed));
      }
      else if (speed < 0) {
        digitalWrite(ATOM128_Motor4_IN, LOW);
        analogWrite(ATOM128_Motor4_PWM, abs(speed));
      }
      else {
        digitalWrite(ATOM128_Motor4_IN, LOW);
        analogWrite(ATOM128_Motor4_PWM, 0);
      }
    }
  }
  else if (_model == ATOMX2 || _model == ATOMmini) {
    if (motor == 1) {
      if (speed > 0) {
        digitalWrite(ATOM64_Motor1_IN1, HIGH);
        digitalWrite(ATOM64_Motor1_IN2, LOW);
        analogWrite(ATOM64_Motor1_PWM, abs(speed));
      }
      else if (speed < 0) {
        digitalWrite(ATOM64_Motor1_IN1, LOW);
        digitalWrite(ATOM64_Motor1_IN2, HIGH);
        analogWrite(ATOM64_Motor1_PWM, abs(speed));
      }
      else {
        digitalWrite(ATOM64_Motor1_IN1, HIGH);
        digitalWrite(ATOM64_Motor1_IN2, HIGH);
        analogWrite(ATOM64_Motor1_PWM, 255);
      }
    }
    else if (motor == 2) {
      if (speed > 0) {
        digitalWrite(ATOM64_Motor2_IN1, HIGH);
        digitalWrite(ATOM64_Motor2_IN2, LOW);
        analogWrite(ATOM64_Motor2_PWM, abs(speed));
      }
      else if (speed < 0) {
        digitalWrite(ATOM64_Motor2_IN1, LOW);
        digitalWrite(ATOM64_Motor2_IN2, HIGH);
        analogWrite(ATOM64_Motor2_PWM, abs(speed));
      }
      else {
        digitalWrite(ATOM64_Motor2_IN1, HIGH);
        digitalWrite(ATOM64_Motor2_IN2, HIGH);
        analogWrite(ATOM64_Motor2_PWM, 255);
      }
    }
  }
}

void ATOM::setRotation(byte rotation) {
  _rotation = rotation;
  dply.begin();
  dply.setRotation(_rotation);
}

void ATOM::setTextSize(byte size) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setTextSize(size);
  }
  else if (_model == ATOMmini) {
    display.setTextSize(size);
  }
}

void ATOM::fillScreen(uint16_t color) {
  _fillcolor = color;
  dply.begin();
  dply.setRotation(_rotation);
  dply.fillScreen(_fillcolor);
}

void ATOM::setTextColor(uint16_t color) {
  _color1 = color;
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setTextColor(color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.setTextColor(1);
      display.display();
    }
    else {
      display.setTextColor(0);
      display.display();
    }
  }
}

void ATOM::setTextColor(uint16_t a, uint16_t b) {
  _color1 = a;
  _color2 = b;
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setTextColor(a, b);
  }
  else if (_model == ATOMmini) {
    bool color1, color2;
    if (a == WHITE) {
      color1 = 1;
    }
    else {
      color1 = 0;
    }

    if (b == WHITE) {
      color2 = 1;
    }
    else {
      color2 = 0;
    }

    display.setTextColor(color1, color2);
  }
}

void ATOM::printSegment(int num, int16_t x, int16_t y, uint16_t color) {
  dply.begin();
  dply.setRotation(_rotation);
  if (num >= 1000 && num < 10000) {
    dply.setTextColor(_fillcolor, _fillcolor);
    dply.drawNumber(8, 136 + x, y, 7);
    dply.setTextColor(color, _fillcolor);
  }
  else if (num >= 100 && num < 1000) {
    dply.setTextColor(_fillcolor, _fillcolor);
    dply.drawNumber(88, 102 + x, y, 7);
    dply.setTextColor(color, _fillcolor);
  }
  else if (num >= 10 && num < 100) {
    dply.setTextColor(_fillcolor, _fillcolor);
    dply.drawNumber(888, 68 + x, y, 7);
    dply.setTextColor(color, _fillcolor);
  }
  else if (num < 10) {
    dply.setTextColor(_fillcolor, _fillcolor);
    dply.drawNumber(8888, 34 + x, y, 7);
    dply.setTextColor(color, _fillcolor);
  }

  dply.drawNumber(num, x, y, 7);
}

void ATOM::setCursor(int16_t x, int16_t y) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setCursor(x, y);
  }
  else if (_model == ATOMmini) {
    display.setCursor(x, y);
  }
}

void ATOM::print(String string, int16_t x, int16_t y, uint16_t color) {
  dply.begin();
  dply.setRotation(_rotation);
  dply.setCursor(x, y);
  dply.setTextColor(color);
  dply.print(string);
}

void ATOM::print(String string, int16_t x, int16_t y, uint16_t color1, uint16_t color2) {
  dply.begin();
  dply.setRotation(_rotation);
  dply.setCursor(x, y);
  dply.setTextColor(color1, color2);
  dply.print(string);
}

void ATOM::println(String string, int16_t x, int16_t y, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setCursor(x, y);
    dply.setTextColor(color);
    dply.println(string);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.setCursor(x, y);
      display.setTextColor(1);
      display.println(string);
      display.display();
    }
    else {
      display.setCursor(x, y);
      display.setTextColor(0);
      display.println(string);
      display.display();
    }
  }
}

void ATOM::println(String string, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setTextColor(color);
    dply.println(string);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.setTextColor(1);
      display.println(string);
      display.display();
    }
    else {
      display.setTextColor(0);
      display.println(string);
      display.display();
    }
  }
}

void ATOM::println(String string, int16_t x, int16_t y, uint16_t color1, uint16_t color2) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setCursor(x, y);
    dply.setTextColor(color1, color2);
    dply.println(string);
  }
  else if (_model == ATOMmini) {
    if (color1 == WHITE) {
      color1 = 1;
    }
    else {
      color1 = 0;
    }

    if (color2 == WHITE) {
      color2 = 1;
    }
    else {
      color2 = 0;
    }

    display.setCursor(x, y);
    display.setTextColor(color1, color2);
    display.println(string);
    display.display();
  }
}

void ATOM::printNumber(int num, int16_t x, int16_t y, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.setCursor(x, y);
    dply.setTextColor(color, _fillcolor);
    if (num == 0) {
      dply.print("0   ");
    }
    else if (num > 0 && num < 10) {
      dply.print(num);
      dply.print("   ");
    }
    else if (num >= 10 && num < 100) {
      dply.print(num);
      dply.print("  ");
    }
    else if (num >= 100 && num < 1000) {
      dply.print(num);
      dply.print(" ");
    }
    else if (num > 1000 && num < 10000) {
      dply.print(num);
    }
    else if (num < 0 && num > -10) {
      dply.print(num);
      dply.print("   ");
    }
    else if (num < -10 && num > -100) {
      dply.print(num);
      dply.print("  ");
    }
    else if (num < -100 && num > -1000) {
      dply.print(num);
      dply.print(" ");
    }
    else if (num < -1000 && num > -10000) {
      dply.print(num);
    }
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.setCursor(x, y);
      display.setTextColor(1);
      display.println(num, DEC);
      display.display();
    }
    else {
      display.setCursor(x, y);
      display.setTextColor(0);
      display.println(num, DEC);
      display.display();
    }
  }
}

void ATOM::clearScreen() {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.fillScreen(_fillcolor);
  }
  else if (_model == ATOMmini) {
    display.clearDisplay();
  }
}

void ATOM::drawPixel(int16_t x, int16_t y, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.writePixel(x, y, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.drawPixel(x, y, 1);
      display.display();
    }
    else {
      display.drawPixel(x, y, 0);
      display.display();
    }
  }
}

void ATOM::drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.drawRect(x, y, w, h, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.drawRect(x, y, w, h, 1);
      display.display();
    }
    else {
      display.drawRect(x, y, w, h, 1);
      display.display();
    }
  }
}

void ATOM::drawFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.writeFillRect(x, y, w, h, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.fillRect(x, y, w, h, 1);
      display.display();
    }
    else {
      display.fillRect(x, y, w, h, 1);
      display.display();
    }
  }
}

void ATOM::drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.drawLine(x0, y0, x1, y1, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.drawLine(x0, y0, x1, y1, 1);
      display.display();
    }
    else {
      display.drawLine(x0, y0, x1, y1, 0);
      display.display();
    }
  }
}

void ATOM::drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.drawCircle(x0, y0, r, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.drawCircle(x0, y0, r, 1);
      display.display();
    }
    else {
      display.drawCircle(x0, y0, r, 0);
      display.display();
    }
  }
}

void ATOM::drawFillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.fillCircle(x0, y0, r, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.fillCircle(x0, y0, r, 1);
      display.display();
    }
    else {
      display.fillCircle(x0, y0, r, 0);
      display.display();
    }
  }
}

void ATOM::drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.drawTriangle(x0, y0, x1, y1, x2, y2, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.drawTriangle(x0, y0, x1, y1, x2, y2, 1);
      display.display();
    }
    else {
      display.drawTriangle(x0, y0, x1, y1, x2, y2, 0);
      display.display();
    }
  }
}

void ATOM::drawFillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color) {
  if (_model == ATOMX2 || _model == ATOMX4) {
    dply.begin();
    dply.setRotation(_rotation);
    dply.fillTriangle(x0, y0, x1, y1, x2, y2, color);
  }
  else if (_model == ATOMmini) {
    if (color == WHITE) {
      display.fillTriangle(x0, y0, x1, y1, x2, y2, 1);
      display.display();
    }
    else {
      display.fillTriangle(x0, y0, x1, y1, x2, y2, 0);
      display.display();
    }
  }
}