#ifndef PTBOT_Atom1_h
#define PTBOT_Atom1_h

#if defined(ARDUINO) || (ARDUINO >= 100)
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include "Arduino.h"
#include <Adafruit_MCP3008.h>
#include <Servo.h>
#include <EEPROM.h>
#include <Adafruit_ILI9341_STM.h>
#include <Adafruit_GFX_AS.h>

/* MODEL ************************************************/
#define ATOM64 0
#define ATOM128 1
/********************************************************/

/* DEFINE PIN *******************************************/
#define ADC1 0
#define ADC2 1
#define ADC3 2
#define ADC4 3
#define ADC5 4
#define ADC6 5
#define ADC7 6
#define ADC8 7
#define Buzer_PIN PB9
#define LED_PIN PC13
#define Button_PIN PA13
#define CLOCK_PIN PA5
#define MOSI_PIN PA7
#define MISO_PIN PA6
#define SS_ADC_PIN PB5
#define TFT_CS PA14
#define TFT_DC PB3
#define TFT_RST PA15
#define Motor1_IN PB13
#define Motor1_PWM PB0
#define Motor2_IN PB14
#define Motor2_PWM PB1
#define Motor3_IN PB12
#define Motor3_PWM PB8
#define Motor4_IN PB15
#define Motor4_PWM PA8
/********************************************************/

/* NOTE BUZZER ******************************************/
#define note_C 523
#define note_D 587
#define note_E 659
#define note_F 698
#define note_G 783
#define note_A 880
#define note_B 987
#define note_CC 1046
/********************************************************/

/* DISPLAY COLORS ***************************************/
#define BLACK 0x0000
#define WHITE 0xFFFF
#define GREY 0x7BEF
#define LIGHT_GREY 0xC618
#define GREEN 0x07E0
#define LIME 0x87E0
#define BLUE 0x001F
#define RED 0xF800
#define AQUA 0x5D1C
#define YELLOW 0xFFE0
#define MAGENTA 0xF81F
#define CYAN 0x07FF
#define DARK_CYAN 0x03EF
#define ORANGE 0xFCA0
#define PINK 0xF97F
#define BROWN 0x8200
#define VIOLET 0x9199
#define SILVER 0xA510
#define GOLD 0xA508
#define NAVY 0x000F
#define MAROON 0x7800
#define PURPLE 0x780F
#define OLIVE 0x7BE0
/********************************************************/

class ATOM {
  public:
    //SETUP MODEL
    ATOM(byte model);

    //SETUP INPUT AND OUTPUT
    void IOSetup();

    //BUZZER
    void Tone(int note, unsigned int time);

    //READ ANALOG 10 BIT FROM MCP3008
    unsigned int ADCRead(byte channel);

    //SET LINE SENSOR PIN AND NUM OF SENSOR
    void LINESensorSET(byte adcchannel[], byte num_sensor);

    //CALIBRATE LINE SENSOR AND SAVE TO EEPROM
    void LINECalibrate();

    //CHANGE COLOR LINE
    void LINEToggle();

    //GET POSITION FROM LINE SENSOR
    int GETPosition();

    //SETUP LINE CHART
    void LINEChartSET(byte adcchannel[], byte num_sensor);

    //SHOW VALUE SENSOR CHART
    void LINEChartSHOW(int16_t x);

    //CONTORL SERVO
    void servoWrite(byte pin, byte degree);

    //CONTROL MOTOR
    void motorWrite(byte motor, int speed);

    //SET DISPLAY ROTATION
    void setRotation(byte rotation);

    //SET DISPLAY TEXT SIZE
    void setTextSize(byte size);

    //DISPLAY FILL
    void fillScreen(uint16_t color);

    //SET DISPLAY TEXT COLOR
    void setTextColor(uint16_t color);

    //SET DISPLAY TEXT COLOR
    void setTextColor(uint16_t a, uint16_t b);
    
    //DISPLAY DRAW NUMBER 7 SEGMENT
    void printSegment(int num, int16_t x, int16_t y, uint16_t color);

    //DISPLAY SET CURSOR
    void setCursor(int16_t x, int16_t y);

    //DISPLAY PRINT
    void print(String string, int16_t x, int16_t y, uint16_t color);

    //DISPLAY PRINT WITH BACKGROUND
    void print(String string, int16_t x, int16_t y, uint16_t color1, uint16_t color2);

    //DISPLAY PRINT LINE NEW
    void println(String string, int16_t x, int16_t y, uint16_t color);

    //DISPLAY PRINT LINE NEW ONLY
    void println(String string, uint16_t color);

    //DISPLAY PRINT LINE NEW WITH BACKGROUND
    void println(String string, int16_t x, int16_t y, uint16_t color1, uint16_t color2);

    //DISPLAY PRINT NUMBER
    void printNumber(int num, int16_t x, int16_t y, uint16_t color);

    //DISPLAY CLEAR
    void clearScreen();

    //DISPLAY PRINT PIXEL
    void drawPixel(int16_t x, int16_t y, uint16_t color);

    //DISPLAY PRINT RECTANGLE
    void drawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);

    //DISPLAY PRINT FILL RECTANGLE
    void drawFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);

    //DISPLAY PRINT LINE
    void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);

    //DISPLAY PRINT CIRCLE
    void drawCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);

    //DISPLAY PRINT FILL CIRCLE
    void drawFillCircle(int16_t x0, int16_t y0, int16_t r, uint16_t color);

    //DISPLAY PRINT TRIANGLE
    void drawTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color);

    //DISPLAY PRINT FILL TRIANGLE
    void drawFillTriangle(int16_t x0, int16_t y0, int16_t x1, int16_t y1, int16_t x2, int16_t y2, uint16_t color);

  private:
    byte _model;
    unsigned long _timer;

    /* LINE SENSOR ******************************************/
    byte Line_Address;
    byte Background_Address;
    byte Sensor_PIN[8];
    byte Num_Sensor;
    unsigned int Color_Line[8];
    unsigned int Color_Background[8];
    unsigned int Last_Position;
    bool Line_Mode;
    byte _chartpin[8];
    byte _numchart;
    /********************************************************/

    /* TFTLCD ***********************************************/
    uint8_t _rotation;
    uint16_t _fillcolor;
    uint16_t _color1;
    uint16_t _color2;
    /********************************************************/
};

#endif