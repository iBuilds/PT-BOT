This library is based on
  - Adafruit ILI9341
  - Adafruit GFX AS
  - Adafruit_MCP3008
  - Servo
  - EEPROM
  - SPI


_________________________  Original text from Adafruit ILI9341  _________________________

This is a library for the Adafruit ILI9341 display products

This library works with the Adafruit 2.8" Touch Shield V2 (SPI)
  ----> http://www.adafruit.com/products/1651
 
Check out the links above for our tutorials and wiring diagrams.
These displays use SPI to communicate, 4 or 5 pins are required
to interface (RST is optional).

Adafruit invests time and resources providing this open source code,
please support Adafruit and open-source hardware by purchasing
products from Adafruit!

Written by Limor Fried/Ladyada for Adafruit Industries.
MIT license, all text above must be included in any redistribution

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder Adafruit_ILI9341. Check that the Adafruit_ILI9341 folder contains Adafruit_ILI9341.cpp and Adafruit_ILI9341.

Place the Adafruit_ILI9341 library folder your arduinosketchfolder/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE

Also requires the Adafruit_GFX library for Arduino.


_________________________  Original text from Adafruit GFX AS  _________________________

This library adds a few font-related functions on top of the Adafruit_GFX library (which you need to install, separately).

Historically, Adafruit_GFX_AS started as a fork of Adafruit_GFX. Most importantly, it added support for using additional fonts,
before similar functionality became available in Adafruit_GFX.

Today, the main point of this library is to continue supporting projects that have made use of the functions added in Adafruit_GFX_AS,
while also being fully compatible with Adafruit_GFX (which is used as the base class). It is not recommended to use the functions
provided by the Adafruit_GFX_AS class in newly developed code.

To use this library with a driver that is not based on Adafruit_GFX_AS, all you will have to do is to replace "Adafrui_GFX" with "Adafruit_GFX_AS"
in your driver code. This will usually be three places: The #include-directive, the base-class declaration, and the call to the base-contstructor.

Adafruit invests time and resources providing this open source code, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Adafruit_GFX Written by Limor Fried/Ladyada for Adafruit Industries.
Adafruit_GFX_AS funtions added by "Bodmer"(?)
BSD license, check license.txt for more information.
All text above must be included in any redistribution.

To download, click the DOWNLOAD ZIP button, uncompress and rename the uncompressed folder Adafruit_GFX_AS. Confirm that the Adafruit_GFX_AS folder contains Adafruit_GFX_AS.cpp and Adafruit_GFX_AS.h

Place the Adafruit_GFX_AS library folder your <arduinosketchfolder>/Libraries/ folder. You may need to create the Libraries subfolder if its your first library. Restart the IDE.


_________________________  Original text from Adafruit_MCP3008  _________________________

Adafruit_MCP3008 [![Build Status](https://travis-ci.com/adafruit/Adafruit_MCP3008.svg?branch=master)](https://travis-ci.com/adafruit/Adafruit_MCP3008)
================

<a href="https://www.adafruit.com/product/856"><img src="assets/board.jpg?raw=true" width="500px"></a>

This is the Adafruit MCP3008 - 8-Channel 10-Bit ADC With SPI Interface Library.

Tested for the following boards using pins shown.

MCP3008 | UNO | FEATHER HUZZAH<sup>1</sup> | FEATHER 32u4 | FEATHER M0
:---: | :---: | :---: | :---: | :---:
VDD | 5V | 3V | 3V | 3V 
VREF | 5V | 3V | 3V | 3V
AGND | GND | GND | GND | GND
CLK | 13 | SCK (14) | SCK | SCK
DOUT | 12 | MI (12) | MISO | MISO
DIN | 11 | MO (13) | MOSI | MOSI
CS | 10 | any<sup>2</sup> (15) | any<sup>2</sup> | any<sup>2</sup>
DGND | GND | GND | GND | GND

<sup>1</sup>also works for non-Feather HUZZAH, use (XX) pins

<sup>2</sup>use any available digital pin